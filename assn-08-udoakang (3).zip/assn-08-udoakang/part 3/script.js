// Function to add a new todo item
function addTodo() {
    const todoInput = document.getElementById('todoInput');
    const todoText = todoInput.value.trim();

    if (todoText) {
        const todoList = document.getElementById('todoList');

        // Create new list item
        const listItem = document.createElement('li');
        listItem.innerHTML = `
            <span>${todoText}</span>
            <button class="delete-btn" onclick="deleteTodo(this)">Delete</button>
        `;

        // Append the new item to the todo list
        todoList.appendChild(listItem);

        // Clear the input field
        todoInput.value = '';
    } else {
        alert('Please enter a valid todo.');
    }
}

// Function to delete a todo item
function deleteTodo(button) {
    const listItem = button.parentNode;
    const todoList = listItem.parentNode;

    // Remove the list item from the todo list
    todoList.removeChild(listItem);
}
