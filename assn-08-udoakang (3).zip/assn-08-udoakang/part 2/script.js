// Check if local storage has existing blog entries
const blogEntries = JSON.parse(localStorage.getItem('blogEntries')) || [];

// Function to save blog entries to local storage
function saveBlogEntries() {
    localStorage.setItem('blogEntries', JSON.stringify(blogEntries));
}

// Initialize blog entries from local storage
function loadBlogEntries() {
    // Clear existing entries
    entries.innerHTML = '';

    // Load entries from local storage
    blogEntries.forEach((entry) => {
        createBlogEntry(entry);
    });
}

// Call loadBlogEntries on page load
document.addEventListener('DOMContentLoaded', loadBlogEntries);

// Function to submit a new blog entry
function submitBlogEntry() {
    const authorInput = document.getElementById('authorInput');
    const blogEntryInput = document.getElementById('blogEntryInput');

    const author = authorInput.value.trim();
    const blogEntry = blogEntryInput.value.trim();
    const dateTime = new Date().toLocaleString();

    if (author && blogEntry) {
        const newEntry = {
            author: author,
            text: blogEntry,
            timestamp: dateTime,
        };

        // Add the new entry to the list
        blogEntries.unshift(newEntry);

        // Save entries to local storage
        saveBlogEntries();

        // Reload and display entries
        loadBlogEntries();

        // Clear input fields
        authorInput.value = '';
        blogEntryInput.value = '';
    } else {
        alert('Please enter both your name and a blog post.');
    }
}

// Function to create a blog entry
function createBlogEntry(entry) {
    const entries = document.getElementById('entries');

    const entryElement = document.createElement('div');
    entryElement.classList.add('entry');
    entryElement.innerHTML = `
        <h3>${entry.author}</h3>
        <p>${entry.text}</p>
        <small>${entry.timestamp}</small>
    `;

    entries.appendChild(entryElement);
}
