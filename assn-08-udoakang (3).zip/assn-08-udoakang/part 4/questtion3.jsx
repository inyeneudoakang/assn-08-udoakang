import React from 'react';

const CSSInReactComparison = () => {
  return (
    <div>
      <h2>CSS in React Comparison</h2>
      <p>
        Applying CSS in React differs from plain JavaScript in that styles are often encapsulated within
        components using the "Styled Components" library or through CSS-in-JS solutions. This encapsulation
        enhances modularity and avoids global styling conflicts. Additionally, React encourages the use of
        inline styles or CSS modules for styling individual components.
      </p>
    </div>
  );
};

export default CSSInReactComparison;
