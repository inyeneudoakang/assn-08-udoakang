// Check if local storage has existing todo items
const todoItems = JSON.parse(localStorage.getItem('todoItems')) || [];

// Function to save todo items to local storage
function saveTodoItems() {
    localStorage.setItem('todoItems', JSON.stringify(todoItems));
}

// Initialize todo items from local storage
function loadTodoItems() {
    // Clear existing items
    todoList.innerHTML = '';
    completedList.innerHTML = '';

    // Load items from local storage
    todoItems.forEach((item, index) => {
        if (item.completed) {
            createCompletedItem(item, index);
        } else {
            createTodoItem(item, index);
        }
    });

    // Update completion percentage display
    updateCompletionPercentage();
}

// Call loadTodoItems on page load
document.addEventListener('DOMContentLoaded', loadTodoItems);

// Function to add a new todo item
function addTodo() {
    const todoInput = document.getElementById('todoInput');
    const todoText = todoInput.value.trim();

    if (todoText) {
        const newItem = {
            text: todoText,
            completed: false,
        };

        todoItems.push(newItem);
        saveTodoItems();
        loadTodoItems();

        // Clear the input field
        todoInput.value = '';
    } else {
        alert('Please enter a valid todo.');
    }
}

// Function to create a todo item
function createTodoItem(item, index) {
    const todoList = document.getElementById('todoList');

    const listItem = document.createElement('li');
    listItem.innerHTML = `
        <span>${item.text}</span>
        <button class="complete-btn" onclick="completeTodo(${index})">Complete</button>
        <button class="delete-btn" onclick="deleteTodo(${index})">Delete</button>
    `;

    todoList.appendChild(listItem);
}

// Function to create a completed item
function createCompletedItem(item, index) {
    const completedList = document.getElementById('completedList');

    const listItem = document.createElement('li');
    listItem.innerHTML = `
        <span>${item.text}</span>
        <button class="delete-btn" onclick="deleteCompleted(${index})">Delete</button>
    `;

    completedList.appendChild(listItem);
}

// Function to complete a todo item
function completeTodo(index) {
    todoItems[index].completed = true;
    saveTodoItems();
    loadTodoItems();
}

// Function to delete a todo item
function deleteTodo(index) {
    todoItems.splice(index, 1);
    saveTodoItems();
    loadTodoItems();
}

// Function to delete a completed item
function deleteCompleted(index) {
    todoItems.splice(index, 1);
    saveTodoItems();
    loadTodoItems();
}

// Function to update completion percentage display
function updateCompletionPercentage() {
    const completedCount = todoItems.filter(item => item.completed).length;
    const totalItems = todoItems.length;
    const completionPercentage = totalItems === 0 ? 0 : Math.floor((completedCount / totalItems) * 100);
    const completionPercentageElement = document.getElementById('completionPercentage');
    completionPercentageElement.textContent = `Completion: ${completionPercentage}%`;
}
